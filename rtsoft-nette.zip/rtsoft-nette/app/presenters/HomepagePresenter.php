<?php

namespace App\Presenters;

use Nette;


class HomepagePresenter extends Nette\Application\UI\Presenter
{
     /** @var Nette\Database\Context */
     private $database;

     public function __construct(Nette\Database\Context $database)
     {
         $this->database = $database;
     }
 
    /* Generuje data z tabulky */
    public function renderDefault()
    {
    $this->template->posts = $this->database->table('projekty')
        ->order('id DESC')
        ->limit(5);
    }

    /*  vlastní funkce kontroluje, zda je hodnota prázdná  */
    public function isEmpty($item) 
    {
        if ($item == null || $item == '' ) {
            $ie = true;
        } else {
            $ie = false;
        }
        return $ie;    
    }

    /* generuje formulář pro PŘÍDÁNÍ dat */
    protected function createComponentAddForm()
    {
        $form = new Nette\Application\UI\Form; // means Nette\Application\UI\Form

        $form->addText('nazev', 'Název:')
        ->setRequired();
        $form->addText('datum_ddl', 'Datum:')
        ->setRequired()->setType('date');
        $form->addSelect('typ', 'Typ:', [
            'casove' => 'časově omezený projekt',
            'continuous' => 'Continuous Integration'
        ])->setRequired();
        $form->addCheckbox('webovy', 'Webový', 'ano');
        $form->onSuccess[] = [$this, 'addFormSucceeded'];
        $form->addSubmit('send', 'Přidat projekt');
        return $form;
    }

    /* akce pro PŘÍDÁNÍ dat */
    public function addFormSucceeded($form, $values)
    {
        $this->database->table('projekty')->insert([
            'nazev' => $values->nazev,
            'datum_ddl' => $values->datum_ddl,
            'typ' => $values->typ,
            'webovy' => $values->webovy,
        ]);

        $this->flashMessage('Přidáno!', 'success');
        $this->redirect('this');
    }

    /* generuje formulář pro UPRAVENÍ*/
    protected function createComponentEditForm()
    {
        $form = new Nette\Application\UI\Form; // means Nette\Application\UI\Form
        $form->addText('id', 'ID:');
        $form->addText('nazev', 'Název:');
        $form->addText('datum_ddl', 'Datum:')->setType('date');
        $form->addSelect('typ', 'Typ:', [
            'casove' => 'časově omezený projekt',
            'continuous' => 'Continuous Integration'
        ])->setPrompt(null);
        $form->addCheckbox('webovy', 'Webový', 'ano');
        
        $form->onSuccess[] = [$this, 'editFormSucceeded'];
        $form->addSubmit('save', 'Uložit projekt');
    
        return $form;
    }

    /* akce pro UPRAVENÍ dat podle */
    public function editFormSucceeded($form, $values)
    {   
        
        // kontroluje jestli byla zadána hodnota do formuáře, pokud ano tak je upraví v DB
        if (!$this->isEmpty($values->nazev)) {
            $this->database->query('UPDATE projekty SET', [
                'nazev' => $values->nazev
            ], 'WHERE id = ?', $values->id);
        }
        if (!$this->isEmpty($values->datum_ddl)) {
            $this->database->query('UPDATE projekty SET', [
                'datum_ddl' => $values->datum_ddl
            ], 'WHERE id = ?', $values->id);
        }
        if (!$this->isEmpty($values->typ)) {
            $this->database->query('UPDATE projekty SET', [
                'typ' => $values->typ
            ], 'WHERE id = ?', $values->id);
        }

        // "webový" ukládá hodnotu pokažké protože nejde nechat "prázdná" leda při předělání formuláře na ANO/NE
        $this->database->query('UPDATE projekty SET', [
            'webovy' => $values->webovy
        ], 'WHERE id = ?', $values->id);

       // kontrola ID - nezadáno, nenalezeno, upraveno
       $nalezeno = $this->database->fetch('SELECT * FROM projekty WHERE id = ?', $values->id);
       if ($this->isEmpty($values->id)) {
            $this->flashMessage('ID nebylo zadáno!', 'success');
        } else if ($nalezeno == '0') {
            $this->flashMessage('ID nebylo nalezeno!', 'success');
        }  else {
            $this->flashMessage('Upraveno!', 'success');
        }
        
        $this->redirect('this');
    }

    /* generuje formulář pro SMAZÁNÍ */
    protected function createComponentDeleteForm()
    {       
        $form = new Nette\Application\UI\Form; // means Nette\Application\UI\Form
        $form->addText('id', 'ID:');
        $form->onSuccess[] = [$this, 'deleteFormSucceeded'];
        $form->addSubmit('delete', 'Smazat projekt');
        return $form;
    }

    /* akce pro SMAZÁNÍ dat podle ID */
    public function deleteFormSucceeded($form, $values)
    {
        // kontrola ID - nezadáno, nenalezeno, smazáno
       $nalezeno = $this->database->fetch('SELECT * FROM projekty WHERE id = ?', $values->id);
       if ($this->isEmpty($values->id)) {
            $this->flashMessage('ID nebylo zadáno!', 'success');
        } else if ($nalezeno == '0') {
            $this->flashMessage('ID nebylo nalezeno!', 'success');
        }  else {
            $this->database->query('DELETE FROM projekty WHERE id = ?', $values->id);        
            $this->flashMessage('Bylo smazáno ID'. $values->id .'!', 'success');
        }
        $this->redirect('this');
    }

        
}


