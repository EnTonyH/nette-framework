<?php
// source: /Applications/MAMP/htdocs/rtsoft-nette/app/presenters/templates/Homepage/default.latte

use Latte\Runtime as LR;

class Template81c8b4eb26 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
		'title' => 'blockTitle',
	];

	public $blockTypes = [
		'content' => 'html',
		'title' => 'html',
	];


	function main()
	{
		extract($this->params);
?>

<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['projekt'])) trigger_error('Variable $projekt overwritten in foreach on line 18');
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
	<h1>Přidat nový projekt</h1>

<?php
		/* line 5 */ $_tmp = $this->global->uiControl->getComponent("addForm");
		if ($_tmp instanceof Nette\Application\UI\IRenderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
?>

	<h1>Upravit projekt podle ID</h1>
	
<?php
		/* line 9 */ $_tmp = $this->global->uiControl->getComponent("editForm");
		if ($_tmp instanceof Nette\Application\UI\IRenderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
?>

	<h1>Smazat projekt podle ID</h1>

<?php
		/* line 13 */ $_tmp = $this->global->uiControl->getComponent("deleteForm");
		if ($_tmp instanceof Nette\Application\UI\IRenderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
?>
				
<?php
		$this->renderBlock('title', get_defined_vars());
?>

	<!--  zmenit na (control něcoForm) a smyčkov vytisknut v php, žádná smyčka, kvuli set defaults -->
<?php
		$iterations = 0;
		foreach ($posts as $projekt) {
?>
 	<div class="projekt">
		<h2><?php echo LR\Filters::escapeHtmlText($projekt->nazev) /* line 20 */ ?></h2>
		<div>ID: <?php echo LR\Filters::escapeHtmlText($projekt->id) /* line 21 */ ?></div>
		<div class="date">Datum odevzdání: <?php echo LR\Filters::escapeHtmlText(call_user_func($this->filters->date, $projekt->datum_ddl, 'd.m.Y')) /* line 22 */ ?></div>
		<div>Typ: <?php echo LR\Filters::escapeHtmlText($projekt->typ) /* line 23 */ ?></div>
		<div>Webový projekt: <?php echo LR\Filters::escapeHtmlText($projekt->webovy) /* line 24 */ ?></div>
    </div>
<?php
			$iterations++;
		}
		
	}


	function blockTitle($_args)
	{
		extract($_args);
?>    <h1>Přehled projektů</h1>
<?php
	}

}
